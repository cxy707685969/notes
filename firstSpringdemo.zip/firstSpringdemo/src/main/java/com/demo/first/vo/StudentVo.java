package com.demo.first.vo;

import lombok.Data;

@Data
public class StudentVo {
    private String id;
    private String name;
    private char sex;
    private String phone;
}
