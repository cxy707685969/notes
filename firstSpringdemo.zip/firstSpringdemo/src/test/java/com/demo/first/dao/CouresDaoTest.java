package com.demo.first.dao;

import static org.junit.Assert.*;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

public class CouresDaoTest {

    @Autowired
    private CouresDao couresDao;

    @Test
    public void findByClassIdIsIn() {
    }
}